﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Xml2CSharp;

namespace DesignPatternsInCSharp.Adapter.ResultWrapper
{
    public class CharacterFileSource
    {
        //public async Task<employees> GetCharactersFromFile(string filename)
        //{
        //    XmlSerializer serializer = new XmlSerializer(typeof(employees));
        //    var result = new employees();
        //    await using (FileStream fileStream = new FileStream(filename, FileMode.Open))
        //    {
        //         result =  (employees)serializer.Deserialize(fileStream);
        //    }
        //    return result;
        //}
        public async Task<List<Character>> GetCharactersFromFile(string filename)
        {
            var characters = JsonConvert.DeserializeObject<List<Character>>(await File.ReadAllTextAsync(filename));

            return characters;
        }
    }
}
