﻿//using System;
//using Xml2CSharp;

//namespace DesignPatternsInCSharp.Adapter.ResultWrapper
//{
//    public class EmployeeToPersonAdapter : Person
//    {
//        private readonly Employee _employee;

//        public EmployeeToPersonAdapter(Employee employee)
//        {
//            _employee = employee ?? throw new ArgumentNullException(nameof(Employee));
//        }

//        public override string Name
//        {
//            get => _employee.Name;
//            set => _employee.Name = value;
//        }

//        public override string HairColor
//        {
//            get => _employee.Hair_color;
//            set => _employee.Hair_color = value;
//        }
//    }
//}
