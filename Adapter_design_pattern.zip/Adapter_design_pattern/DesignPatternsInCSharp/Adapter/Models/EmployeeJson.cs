﻿namespace AdapterDesignPattern.Adapter
{
    public class EmployeeJson
    {
        public string EmployeeName { get; set; }
        public string EIN { get; set; }
        public string EmployeeDesignation { get; set; }
        public string Contact { get; set; }
    }
}
