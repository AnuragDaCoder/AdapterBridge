﻿using System.Xml.Serialization;
using System.Collections.Generic;

namespace EmployeeNewXMlModel
{
	public class EmployeesXMLDetail
	{
		[XmlElement(ElementName = "EmmployeeName")]
		public string Name { get; set; }
		[XmlElement(ElementName = "EIN")]
		public string EIN { get; set; }
		[XmlElement(ElementName = "EmployeeDesignation")]
		public string Designation { get; set; }
		[XmlElement(ElementName = "Contact")]
		public string Contact { get; set; }
	}

	[XmlRoot(ElementName = "Employees")]
	public class EmployeesXML
	{
		[XmlElement(ElementName = "Employee")]
		public List<EmployeesXMLDetail> Employeelist { get; set; }
	}

}


