﻿namespace AdapterDesignPattern.Adapter
{
    public class Employee
    {
        public string Name { get; set; }
        public string EIN { get; set; }
        public string Designation { get; set; }
        public string Contact { get; set; }
    }
}
