﻿using AdapterDesignPattern.Adapter;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DesignPatternsInCSharp.Adapter.Inheritence.DependencyInjectionAutofac
{
    public class EmployeeJsonSourceAdapter : EmployeeAdapteeJsonSource,IEmployeeAdaptor
    {
        private string _fileName;

        public EmployeeJsonSourceAdapter(string fileName)
        {
            _fileName = fileName;
        }

        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            return await GetEmployeeDetailsFromJsonSource(_fileName);
        }
    }
}
