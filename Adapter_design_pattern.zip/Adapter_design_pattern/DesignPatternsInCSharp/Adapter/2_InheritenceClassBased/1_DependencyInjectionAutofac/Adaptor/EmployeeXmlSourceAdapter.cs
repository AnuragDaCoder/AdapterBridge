﻿using AdapterDesignPattern.Adapter;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DesignPatternsInCSharp.Adapter.Inheritence.DependencyInjectionAutofac
{
    public class EmployeeXmlSourceAdapter : EmployeeAdapteeXmlSource,IEmployeeAdaptor
    {
        private string _fileName;

        public EmployeeXmlSourceAdapter(string fileName)
        {
            _fileName = fileName;
        }

        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            return await GetEmployeeDetailsFromXmlSource(_fileName);
        }
    }
}
