﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPatternsInCSharp.Adapter.Inheritence.DependencyInjectionAutofac
{
    public static class Contstant
    {
       public static string xmlpath => @"C:\c#\c-sharp-design-patterns-adapter\02\demos\DesignPatternsInCSharp\DesignPatternsInCSharp\Adapter\Employee.xml";
       public static string jsonpath => @"Adapter/Employee.json";
    }
}
