﻿using AdapterDesignPattern.Adapter;
using AutoMapper;
using EmployeeXMlModel;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DesignPatternsInCSharp.Adapter.Inheritence.DependencyInjectionAutofac
{
    public class EmployeeAdapteeXmlSource
    {
        public async Task<List<Employee>> GetEmployeeDetailsFromXmlSource(string xmlFilepath)
        {
            var result = new EmployeesXML();
            var finalResult = new List<Employee>();
            XmlSerializer serializer = new XmlSerializer(typeof(EmployeesXML));
            await using (FileStream fileStream = new FileStream(xmlFilepath, FileMode.Open))
            {
                result = (EmployeesXML)serializer.Deserialize(fileStream);
            }
            var config = new MapperConfiguration(cfg => cfg.CreateMap<EmployeesXMLDetail, Employee>() );
            var mapper = new Mapper(config);
            return mapper.Map<List<EmployeesXMLDetail>, List<Employee>>(result.Employeelist);
        }
    }
}
