﻿using AdapterDesignPattern.Adapter._05_DependencyInjectionAutofac.Constants;
using Autofac;
using Autofac.Core;
using System.Reflection;

namespace DesignPatternsInCSharp.Adapter.Inheritence.DependencyInjectionAutofac
{
    public static class AutofacBuildObject
    {
        public static IContainer BuildContainer()
        {
            var builder = new ContainerBuilder();
            builder.RegisterAssemblyTypes(Assembly.GetExecutingAssembly()).AsSelf().AsImplementedInterfaces();

            builder.Register(ctx => new EmployeeDetails(ctx.Resolve<EmployeeJsonSourceAdapter>()));
            builder.Register(ctx => new EmployeeDetails(ctx.Resolve<EmployeeXmlSourceAdapter>()));

            builder.Register(ctx => new EmployeeJsonSourceAdapter(Contstant.jsonpath));
            builder.Register(ctx => new EmployeeXmlSourceAdapter(Contstant.xmlpath));
            return builder.Build();
        }
    }
}
