﻿using AdapterDesignPattern.Adapter;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DesignPatternsInCSharp.Adapter.Inheritence.DependencyInjectionAutofac
{
    public interface IEmployeeAdaptor
    {
        Task<IEnumerable<Employee>> GetEmployees();
    }
}
