﻿using AdapterDesignPattern.DependencyInjectionAutofac.ModelDifferent.Constants;
using Autofac;
using System.Reflection;

namespace DesignPatternsInCSharp.Adapter.DependencyInjectionAutofac.ModelDifferent
{
    public static class AutofacBuildObject
    {
        public static IContainer BuildContainer()
        {
            var builder = new ContainerBuilder();
            builder.RegisterAssemblyTypes(Assembly.GetExecutingAssembly()).AsSelf().AsImplementedInterfaces();

            builder.Register(ctx => new EmployeeDetails(ctx.Resolve<EmployeeJsonSourceAdapter>()));
            builder.Register(ctx => new EmployeeDetails(ctx.Resolve<EmployeeXmlSourceAdapter>()));

            builder.Register(ctx => new EmployeeJsonSourceAdapter(Contstant.jsonpath, new EmployeeAdapteeJsonSource()));
            builder.Register(ctx => new EmployeeXmlSourceAdapter(Contstant.xmlpath, new EmployeeAdapteeXmlSource()));
            return builder.Build();
        }
    }
}
