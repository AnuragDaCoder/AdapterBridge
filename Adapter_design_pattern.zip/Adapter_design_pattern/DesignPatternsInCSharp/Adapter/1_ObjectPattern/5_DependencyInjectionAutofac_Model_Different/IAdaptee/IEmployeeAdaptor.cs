﻿using AdapterDesignPattern.Adapter;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DesignPatternsInCSharp.Adapter.DependencyInjectionAutofac.ModelDifferent
{
    public interface IEmployeeAdaptor
    {
        Task<IEnumerable<Employee>> GetEmployees();
    }
}
