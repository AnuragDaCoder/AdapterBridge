﻿using Autofac;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace DesignPatternsInCSharp.Adapter.DependencyInjectionAutofac.ModelDifferent
{
    public class EmployeeDetailsTests
    {
        private readonly ITestOutputHelper _output;
        private readonly IContainer _container;
        private readonly ILifetimeScope _scope;

        public EmployeeDetailsTests(ITestOutputHelper output)
        {
            _output = output;
            _container = AutofacBuildObject.BuildContainer();
            _scope = _container.BeginLifetimeScope();
        }

        [Fact]
        public async Task EmployeeDetailsAsJsonFromApi()
        {
             var result = await _scope.Resolve<EmployeeDetails>().GetEmployeeDetails();
            _output.WriteLine(result);
        }

        [Fact]
        public async Task EmployeeDetailsAsXmlFromApi()
        {
            var result = await _scope.Resolve<EmployeeDetails>().GetEmployeeDetails();
            _output.WriteLine(result);
        }
    }
}
