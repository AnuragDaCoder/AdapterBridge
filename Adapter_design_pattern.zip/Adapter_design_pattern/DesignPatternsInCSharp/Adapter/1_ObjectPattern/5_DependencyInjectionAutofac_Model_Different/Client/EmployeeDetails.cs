﻿using AdapterDesignPattern.Adapter;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DesignPatternsInCSharp.Adapter.DependencyInjectionAutofac.ModelDifferent
{
    public class EmployeeDetails 
    {
        private readonly IEmployeeAdaptor _employeeAdaptor;

        public EmployeeDetails(IEmployeeAdaptor employeeAdaptor)
        {
            _employeeAdaptor = employeeAdaptor;
        }

        public async Task<string> GetEmployeeDetails()
        {
            var employees = await _employeeAdaptor.GetEmployees();
            return EmployeeDetailsBuilder(employees);
        }

        private static string EmployeeDetailsBuilder(IEnumerable<Employee> employees)
        {
            var employeeSb = new StringBuilder();
            int padding = 30;
            employeeSb.AppendLine($"{"NAME".PadRight(padding)}{"Designation"}");
            employees.ToList().ForEach(emp =>
            {
                employeeSb.AppendLine($"{emp.Name.PadRight(padding)}{emp.Designation}");
            });
            return employeeSb.ToString();
        }
    }
}
