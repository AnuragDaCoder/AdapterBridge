﻿using AdapterDesignPattern.Adapter;
using AutoMapper;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DesignPatternsInCSharp.Adapter.DependencyInjectionAutofac.ModelDifferent
{
    public class EmployeeJsonSourceAdapter : IEmployeeAdaptor
    {
        private string _fileName;
        private readonly EmployeeAdapteeJsonSource _employeeAdapteeJsonSource;

        public EmployeeJsonSourceAdapter(string fileName, EmployeeAdapteeJsonSource employeeAdapteeJsonSource)
        {
            _fileName = fileName;
            _employeeAdapteeJsonSource = employeeAdapteeJsonSource;
        }

        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            var jsonString =_employeeAdapteeJsonSource.GetEmployeeDetailsFromJsonSource(_fileName);
            var employeeJsonlist = JsonConvert.DeserializeObject<List<EmployeeJson>>(jsonString);

            var config = new MapperConfiguration(cfg => cfg.CreateMap<EmployeeJson, Employee>()
                         .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.EmployeeName))
                         .ForMember(dest => dest.Designation, opt => opt.MapFrom(src => src.EmployeeDesignation)));

            var mapper = new Mapper(config);
            return mapper.Map<List<EmployeeJson>, List<Employee>>(employeeJsonlist);
        }
    }
}
