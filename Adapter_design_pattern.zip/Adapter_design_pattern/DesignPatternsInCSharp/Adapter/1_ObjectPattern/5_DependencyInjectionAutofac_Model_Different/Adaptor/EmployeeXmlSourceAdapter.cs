﻿using AdapterDesignPattern.Adapter;
using AutoMapper;
using EmployeeXMlModel;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DesignPatternsInCSharp.Adapter.DependencyInjectionAutofac.ModelDifferent
{
    public class EmployeeXmlSourceAdapter : IEmployeeAdaptor
    {
        private string _fileName;
        private readonly EmployeeAdapteeXmlSource _employeeAdapteeXmlSource;

        public EmployeeXmlSourceAdapter(string fileName, EmployeeAdapteeXmlSource employeeAdapteeXmlSource)
        {
            _fileName = fileName;
            _employeeAdapteeXmlSource = employeeAdapteeXmlSource;
        }

        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            var finalResult = new List<Employee>();
            var employeeXml = _employeeAdapteeXmlSource.GetEmployeeDetailsFromXmlSource(_fileName);
            var serializer = new XmlSerializer(typeof(EmployeesXML));
            EmployeesXML result;
            using (TextReader reader = new StringReader(employeeXml))
            {
                result =  (EmployeesXML)serializer.Deserialize(reader);
            }
            var config = new MapperConfiguration(cfg => cfg.CreateMap<EmployeesXMLDetail, Employee>());
            var mapper = new Mapper(config);
            return mapper.Map<List<EmployeesXMLDetail>, List<Employee>>(result.Employeelist);
        }
    }
}
