﻿using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;
using static DesignPatternsInCSharp.Adapter.TwoProviders.EmployeeDetails;

namespace DesignPatternsInCSharp.Adapter.TwoProviders
{
    public class EmployeeDetailsTests
    {
        private readonly ITestOutputHelper _output;

        public EmployeeDetailsTests(ITestOutputHelper output)
        {
            _output = output;
        }

        [Fact]
        public async Task EmployeeDetailsAsJsonFromApi()
        {
            var service = new EmployeeDetails();

            var result = await service.GetEmployeeDetails(EmployeeFormatFromApi.Json);

            _output.WriteLine(result);
        }

        [Fact]
        public async Task EmployeeDetailsAsXmlFromApi()
        {
            var service = new EmployeeDetails();

            var result = await service.GetEmployeeDetails(EmployeeFormatFromApi.Xml);

            _output.WriteLine(result);
        }
    }
}
