﻿using AdapterDesignPattern.Adapter;
using EmployeeXMlModel;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DesignPatternsInCSharp.Adapter.TwoProviders
{
    public class EmployeeDetails
    {
        public enum EmployeeFormatFromApi
        {
            Json,
            Xml
        }
        public async Task<string> GetEmployeeDetails(EmployeeFormatFromApi type)
        {
            string jsonfilePath = @"Adapter/Employee.json";
            string xmlfilePath = @"C:\c#\c-sharp-design-patterns-adapter\02\demos\DesignPatternsInCSharp\DesignPatternsInCSharp\Adapter\Employee.xml"; ;

            var employees = new List<Employee>();
            if (type.Equals(EmployeeFormatFromApi.Json))
            {
                employees = JsonConvert.DeserializeObject<List<Employee>>(await File.ReadAllTextAsync(jsonfilePath));

            }
            else if (type.Equals(EmployeeFormatFromApi.Xml))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(EmployeesXML));
                using (FileStream fileStream = new FileStream(xmlfilePath, FileMode.Open))
                {
                    var result = (EmployeesXML)serializer.Deserialize(fileStream);

                    result.Employeelist.ForEach(emp =>
                    {
                        employees.Add(new Employee { Name = emp.Name, Designation = emp.Designation });
                    });
                }
            }
            var employeeSb = new StringBuilder();
            int padding = 30;
            System.Console.WriteLine("******************Employee Details***********************");
            employeeSb.AppendLine($"{"NAME".PadRight(padding)}   {"Designation"}");
            employees.ForEach(emp =>
            {
                employeeSb.AppendLine($"{emp.Name.PadRight(padding)}   {emp.Designation}");
            });
            return employeeSb.ToString();
        }
    }
}
