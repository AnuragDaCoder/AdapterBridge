﻿using System.IO;

namespace DesignPatternsInCSharp.Adapter.DependencyInjectionAutofac
{
    public class EmployeeAdapteeJsonSource
    {
        public string  GetEmployeeDetailsFromJsonSource(string jsonPath)
        {
            var jsonString = string.Empty;
            using (StreamReader r = new StreamReader(jsonPath))
            {
                jsonString = r.ReadToEnd();
            }
            return jsonString;
        }
    }
}
