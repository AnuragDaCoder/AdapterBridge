﻿using System.Threading.Tasks;
using System.Xml;

namespace DesignPatternsInCSharp.Adapter.DependencyInjectionAutofac
{
    public class EmployeeAdapteeXmlSource
    {
        public string GetEmployeeDetailsFromXmlSource(string xmlFilepath)
        {
           
            XmlDocument doc = new XmlDocument();
            doc.Load(xmlFilepath);
            string xmlcontents = doc.InnerXml;
            return xmlcontents;
        }
    }
}
