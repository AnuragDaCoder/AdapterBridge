﻿using AdapterDesignPattern.Adapter;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DesignPatternsInCSharp.Adapter.DependencyInjectionAutofac
{
    public class EmployeeJsonSourceAdapter : IEmployeeAdaptor
    {
        private string _fileName;
        private readonly EmployeeAdapteeJsonSource _employeeAdapteeJsonSource;

        public EmployeeJsonSourceAdapter(string fileName, EmployeeAdapteeJsonSource employeeAdapteeJsonSource)
        {
            _fileName = fileName;
            _employeeAdapteeJsonSource = employeeAdapteeJsonSource;
        }

        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            var jsonString =_employeeAdapteeJsonSource.GetEmployeeDetailsFromJsonSource(_fileName);
            return  JsonConvert.DeserializeObject<List<Employee>>(jsonString);
        }
    }
}
