﻿namespace AdapterDesignPattern.Adapter._05_DependencyInjectionAutofac.Constants
{
    public static class Contstant
    {
       //public static string xmlpath => @"C:\c#\c-sharp-design-patterns-adapter\02\demos\DesignPatternsInCSharp\DesignPatternsInCSharp\Adapter\Employee.xml";
       public static string xmlpath => @"C:\Users\611184113\OneDrive - BT Plc\Desktop\Adapter_design_pattern\DesignPatternsInCSharp\Adapter\EmployeeXmlNotMatchingOurModel.xml";
       public static string jsonpath => @"Adapter/Employee.json";
    }
}
