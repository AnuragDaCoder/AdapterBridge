﻿using AdapterDesignPattern.Adapter;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DesignPatternsInCSharp.Adapter.DependencyInjectionAutofac
{
    public interface IEmployeeAdaptor
    {
        Task<IEnumerable<Employee>> GetEmployees();
    }
}
