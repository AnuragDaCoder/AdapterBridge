﻿using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace DesignPatternsInCSharp.Adapter.DependencyInjection
{
    public class EmployeeDetailsTests
    {
        private readonly ITestOutputHelper _output;

        public EmployeeDetailsTests(ITestOutputHelper output)
        {
            _output = output;
        }

        [Fact]
        public async Task EmployeeDetailsAsJsonFromApi()
        {
            string filename = @"Adapter/People.json";
            var service = new EmployeeDetails(
                new EmployeeJsonSourceAdapter(filename, new EmployeeAdapteeJsonSource()));

            var result = await service.GetEmployeeDetails();

            _output.WriteLine(result);
        }

        [Fact]
        public async Task EmployeeDetailsAsXmlFromApi()
        {
            string filename = @"C:\c#\c-sharp-design-patterns-adapter\02\demos\DesignPatternsInCSharp\DesignPatternsInCSharp\Adapter\Employee.xml";
            var service = new EmployeeDetails(
                new EmployeeXmlSourceAdapter(filename, new EmployeeAdapteeXmlSource()));
            var result = await service.GetEmployeeDetails();
            _output.WriteLine(result);
        }
    }
}
