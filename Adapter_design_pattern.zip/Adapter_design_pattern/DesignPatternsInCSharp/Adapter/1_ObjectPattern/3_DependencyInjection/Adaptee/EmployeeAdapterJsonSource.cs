﻿using AdapterDesignPattern.Adapter;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace DesignPatternsInCSharp.Adapter.DependencyInjection
{
    public class EmployeeAdapteeJsonSource
    {
        public async Task<List<Employee>> GetEmployeeDetailsFromJsonSource(string jsonPath)
        {
            return JsonConvert.DeserializeObject<List<Employee>>(await File.ReadAllTextAsync(jsonPath));
        }
    }
}
