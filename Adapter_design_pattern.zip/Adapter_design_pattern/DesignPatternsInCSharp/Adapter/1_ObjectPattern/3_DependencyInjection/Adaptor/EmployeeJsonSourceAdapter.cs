﻿using AdapterDesignPattern.Adapter;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DesignPatternsInCSharp.Adapter.DependencyInjection
{
    public class EmployeeJsonSourceAdapter : IEmployeeAdaptor
    {
        private string _fileName;
        private readonly EmployeeAdapteeJsonSource _employeeAdapteeJsonSource;

        public EmployeeJsonSourceAdapter(string fileName, EmployeeAdapteeJsonSource employeeAdapteeJsonSource)
        {
            _fileName = fileName;
            _employeeAdapteeJsonSource = employeeAdapteeJsonSource;
        }

        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            return await _employeeAdapteeJsonSource.GetEmployeeDetailsFromJsonSource(_fileName);
        }
    }
}
