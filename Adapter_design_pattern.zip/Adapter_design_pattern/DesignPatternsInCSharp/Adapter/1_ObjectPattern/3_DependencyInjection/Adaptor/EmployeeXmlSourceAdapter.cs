﻿using AdapterDesignPattern.Adapter;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DesignPatternsInCSharp.Adapter.DependencyInjection
{
    public class EmployeeXmlSourceAdapter : IEmployeeAdaptor
    {
        private string _fileName;
        private readonly EmployeeAdapteeXmlSource _employeeAdapteeXmlSource;

        public EmployeeXmlSourceAdapter(string fileName, EmployeeAdapteeXmlSource employeeAdapteeXmlSource)
        {
            _fileName = fileName;
            _employeeAdapteeXmlSource = employeeAdapteeXmlSource;
        }

        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            return await _employeeAdapteeXmlSource.GetEmployeeDetailsFromXmlSource(_fileName);
        }
    }
}
