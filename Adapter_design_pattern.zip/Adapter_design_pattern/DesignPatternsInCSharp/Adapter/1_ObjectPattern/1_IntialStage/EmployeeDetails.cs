﻿using System.IO;
using System.Text;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using AdapterDesignPattern.Adapter;

namespace AdapterDesignPattern.Stage1
{
    public class EmployeeDetails
    {
        public async Task<string> GetEmployeeDetails()
        {
            string filePath = @"Adapter/Employee.json";
            var employees = JsonConvert.DeserializeObject<List<Employee>>(await File.ReadAllTextAsync(filePath));
            var employeeSb = new StringBuilder();
            int padding = 30;
            System.Console.WriteLine("******************Employee Details***********************");
            employeeSb.AppendLine($"{"NAME".PadRight(padding)}   {"Designation"}");
            employees.ForEach(emp =>
            {
                employeeSb.AppendLine($"{emp.Name.PadRight(padding)}   {emp.Designation}");
            });
            return employeeSb.ToString();
        }
    }
}
