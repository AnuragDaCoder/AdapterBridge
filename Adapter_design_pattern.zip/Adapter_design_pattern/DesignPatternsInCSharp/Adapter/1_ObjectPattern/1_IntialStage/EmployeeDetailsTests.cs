﻿using AdapterDesignPattern.Stage1;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace DesignPatternsInCSharp.Adapter.Initial
{
    public class EmployeeDetailsTests
    {
        private readonly ITestOutputHelper _output;

        public EmployeeDetailsTests(ITestOutputHelper output)
        {
            _output = output;
        }

        [Fact]
        public async Task InitialEmployeeDetails()
        {
            var service = new EmployeeDetails();
            var result = await service.GetEmployeeDetails();
            _output.WriteLine(result);
        }
    }
}
