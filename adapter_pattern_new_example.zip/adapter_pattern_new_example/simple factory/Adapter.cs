﻿

namespace adapterpattern
{
    public interface IAddress
    {
        MyCompatibleAddress GetAddress();
    }

    public class MyCompatibleAddress
    {
        public string Street_LandMark { get;  set; }
        public string State_PinCode { get;  set; }

        public override string ToString()
        {
            return $"{Street_LandMark} :: {State_PinCode}";
        }

    }

    public class ExternalAddress
    {
        public string Street { get;private set; }
        public string Floor { get;private set; }
        public string Landmark { get;private set; }
        public string Pincode { get;private set; }
        public string State { get;private set; }
        public ExternalAddress(string street,string floor, string landmark, string pincode, string state)
        {
            Street = street;
            Floor = floor;
            Landmark = landmark;
            Pincode = pincode;
            State = state;
        }
    }

    public class ExternalSystem
    {
        public ExternalAddress externalAddress()
        {
            return new ExternalAddress("New Colony", "306", "Uday Plaza", "765001", "Odisha");
        }
    }
    public class AddressObjectAdapter : IAddress
    {
        public MyCompatibleAddress GetAddress()
        {
           var addressExternal = new ExternalSystem().externalAddress();
            return new MyCompatibleAddress()
            {
                State_PinCode = addressExternal.State + "-->" + addressExternal.Pincode,
                Street_LandMark = addressExternal.Street + "-->" + addressExternal.Landmark,
            };
        }
    }

    public class AddressClassAdapter : ExternalSystem,IAddress
    {
        public MyCompatibleAddress GetAddress()
        {
            var addressExternal = base.externalAddress();
            return new MyCompatibleAddress()
            {
                State_PinCode = addressExternal.State + "==>" + addressExternal.Pincode,
                Street_LandMark = addressExternal.Street + "==>" + addressExternal.Landmark,
            };
        }
    }
}
