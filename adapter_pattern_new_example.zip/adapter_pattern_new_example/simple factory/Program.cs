﻿// See https://aka.ms/new-console-template for more information


using adapterpattern;

var obj1 = new AddressObjectAdapter();
Console.WriteLine(obj1.GetAddress().ToString());

var obj2 = new AddressClassAdapter();
Console.WriteLine(obj2.GetAddress().ToString());