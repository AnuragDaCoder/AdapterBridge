﻿
namespace BridgeDesignPattern_New_Requirement_And_SpecialMember_Booking_discount
{
    public class BadmintonCourtHalfYearBooking : IBadmintonMembershipBooking
    {
        public decimal GetPrice() => 1000;
        
    }
}
