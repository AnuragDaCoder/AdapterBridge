﻿
namespace BridgeDesignPattern_New_Requirement_And_SpecialMember_Booking_discount
{
    public class BadmintonCourtHalfYearlySpecialMemberBooking : BadmintonCourtHalfYearBooking,IBadmintonMembershipBooking
    {
        public new decimal GetPrice() => base.GetPrice() * (decimal)0.5;
    }
}
