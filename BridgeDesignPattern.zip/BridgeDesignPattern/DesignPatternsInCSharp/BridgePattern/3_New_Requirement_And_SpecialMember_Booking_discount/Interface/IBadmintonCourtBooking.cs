﻿
namespace BridgeDesignPattern_New_Requirement_And_SpecialMember_Booking_discount
{
    public interface IBadmintonMembershipBooking
    {
        public decimal GetPrice();
    }
}
