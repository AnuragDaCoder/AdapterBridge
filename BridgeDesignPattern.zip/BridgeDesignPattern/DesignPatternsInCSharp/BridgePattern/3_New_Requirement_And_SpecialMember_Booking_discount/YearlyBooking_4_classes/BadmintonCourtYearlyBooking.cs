﻿
namespace BridgeDesignPattern_New_Requirement_And_SpecialMember_Booking_discount
{
    public class BadmintonCourtYearlyBooking : IBadmintonMembershipBooking
    {
        public decimal GetPrice() => 15000;
       
    }
}
