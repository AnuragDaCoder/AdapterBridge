﻿
namespace BridgeDesignPattern_New_Requirement_And_SpecialMember_Booking_discount
{
    public class BadmintonCourtYearlySeniorCitizensBooking : BadmintonCourtYearlyBooking,IBadmintonMembershipBooking
    {
        public new decimal GetPrice() => base.GetPrice() * (decimal)0.6;
    }
}
