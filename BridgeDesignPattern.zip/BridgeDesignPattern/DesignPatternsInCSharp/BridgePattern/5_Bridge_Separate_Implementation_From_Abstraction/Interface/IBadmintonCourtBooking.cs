﻿namespace BridgeDesignPattern4_Separate_Implementation_From_Abstraction_Bridge
{
    public interface IBadmintonMembershipBooking 
    {
        IDiscount discountForMembershipBooking { get; set; }
        public decimal GetPrice();
    }
}
