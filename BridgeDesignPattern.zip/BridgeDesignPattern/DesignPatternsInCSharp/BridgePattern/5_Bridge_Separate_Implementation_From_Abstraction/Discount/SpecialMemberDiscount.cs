﻿
namespace BridgeDesignPattern4_Separate_Implementation_From_Abstraction_Bridge
{
    public class SpecialMemberDiscount : IDiscount
    {
        public decimal GetDiscount()
        {
            return (decimal)0.5;
        }
    }
}
