﻿
namespace BridgeDesignPattern4_Separate_Implementation_From_Abstraction_Bridge
{
    public interface IDiscount
    {
        public decimal GetDiscount();
    }
}
