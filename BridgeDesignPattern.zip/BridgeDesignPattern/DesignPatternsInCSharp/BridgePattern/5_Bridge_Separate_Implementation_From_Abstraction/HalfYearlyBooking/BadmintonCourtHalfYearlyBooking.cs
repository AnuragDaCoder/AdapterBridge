﻿
namespace BridgeDesignPattern4_Separate_Implementation_From_Abstraction_Bridge
{
    public class BadmintonCourtHalfYearlyBooking : IBadmintonMembershipBooking
    {
        public IDiscount discountForMembershipBooking { get; set; }
        public BadmintonCourtHalfYearlyBooking(IDiscount dis)
        {
            discountForMembershipBooking = dis;
        }
        public decimal GetPrice() => discountForMembershipBooking != null ? 10000 * discountForMembershipBooking.GetDiscount() : 10000;
    }
}
