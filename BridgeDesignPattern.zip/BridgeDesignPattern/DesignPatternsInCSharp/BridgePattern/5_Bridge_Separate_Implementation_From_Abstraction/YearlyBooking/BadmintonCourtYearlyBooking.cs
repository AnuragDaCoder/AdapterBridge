﻿
namespace BridgeDesignPattern4_Separate_Implementation_From_Abstraction_Bridge
{
    public class BadmintonCourtYearlyBooking : IBadmintonMembershipBooking
    {
        public IDiscount discountForMembershipBooking { get; set; }
        public BadmintonCourtYearlyBooking(IDiscount dis)
        {
            discountForMembershipBooking = dis;
        }
        public decimal GetPrice() => discountForMembershipBooking != null ? 15000 * discountForMembershipBooking.GetDiscount() : 15000;
    }
}
