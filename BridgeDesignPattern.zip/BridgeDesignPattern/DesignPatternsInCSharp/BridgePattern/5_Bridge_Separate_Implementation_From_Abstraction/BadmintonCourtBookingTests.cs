﻿using Xunit;
using Xunit.Abstractions;
using BridgeDesignPattern4_Separate_Implementation_From_Abstraction;

namespace BridgeDesignPattern4_Separate_Implementation_From_Abstraction_Bridge
{
    public class BadmintonCourtBookingTests
    {
        private readonly ITestOutputHelper _output;

        public BadmintonCourtBookingTests(ITestOutputHelper output)
        {
            _output = output;
        }

        [Fact]
        public void InitialHalfYearlyBooking()
        {
            var halfyearlyBooking = new BadmintonCourtHalfYearlyBooking(new SpecialMemberDiscount());
            var result = halfyearlyBooking.GetPrice();
            _output.WriteLine(result.ToString());
        }

        [Fact]
        public void InitialYearlyBooking()
        {
            var yearlyBookingForGirls = new BadmintonCourtYearlyBooking(new GirlsDiscount());
            var result = yearlyBookingForGirls.GetPrice();
            _output.WriteLine(result.ToString());
        }

        [Fact]
        public void BadmintonCourtHalfYearlySeniorCitizensBooking()
        {
            var seniorCitizensBooking = new BadmintonCourtHalfYearlyBooking(new SeniorCitizenDiscount());
            var result = seniorCitizensBooking.GetPrice();
            _output.WriteLine(result.ToString());
        }
    }
}
