﻿
namespace BridgeDesignPattern.NewRequirement
{
    public class BadmintonCourtYearlyBooking : IBadmintonMembershipBooking
    {
        public decimal GetPrice() => 15000;
       
    }
}
