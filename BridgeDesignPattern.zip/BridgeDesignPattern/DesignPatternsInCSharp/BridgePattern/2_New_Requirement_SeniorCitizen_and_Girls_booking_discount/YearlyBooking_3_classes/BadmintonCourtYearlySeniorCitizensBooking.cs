﻿
namespace BridgeDesignPattern.NewRequirement
{
    public class BadmintonCourtYearlySeniorCitizensBooking : BadmintonCourtYearlyBooking, IBadmintonMembershipBooking
    {
        public new decimal GetPrice() => base.GetPrice() * (decimal)0.6;
    }
}
