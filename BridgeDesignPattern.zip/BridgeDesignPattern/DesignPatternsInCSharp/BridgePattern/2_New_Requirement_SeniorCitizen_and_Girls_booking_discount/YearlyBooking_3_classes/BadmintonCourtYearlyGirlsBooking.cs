﻿
namespace BridgeDesignPattern.NewRequirement
{
    public class BadmintonCourtYearlyGirlsBooking : BadmintonCourtYearlyBooking,IBadmintonMembershipBooking
    {
        public new decimal GetPrice() => base.GetPrice() * (decimal)0.8;
       
    }
}
