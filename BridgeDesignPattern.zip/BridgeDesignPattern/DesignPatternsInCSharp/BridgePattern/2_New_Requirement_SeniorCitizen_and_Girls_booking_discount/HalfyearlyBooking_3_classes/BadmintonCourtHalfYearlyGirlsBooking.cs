﻿
namespace BridgeDesignPattern.NewRequirement
{
    public class BadmintonCourtHalfYearlyGirlsBooking : BadmintonCourtHalfYearBooking,IBadmintonMembershipBooking
    {
        public new decimal GetPrice() => base.GetPrice() * (decimal)0.8;

    }
}
