﻿
namespace BridgeDesignPattern.NewRequirement
{
    public class BadmintonCourtHalfYearlySeniorCitizensBooking : BadmintonCourtHalfYearBooking,IBadmintonMembershipBooking
    {
        public new decimal GetPrice() => base.GetPrice() * (decimal)0.6;

    }
}
