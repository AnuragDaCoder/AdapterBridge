﻿
namespace BridgeDesignPattern.NewRequirement
{
    public class BadmintonCourtHalfYearBooking : IBadmintonMembershipBooking
    {
        public decimal GetPrice() => 1000;
        
    }
}
