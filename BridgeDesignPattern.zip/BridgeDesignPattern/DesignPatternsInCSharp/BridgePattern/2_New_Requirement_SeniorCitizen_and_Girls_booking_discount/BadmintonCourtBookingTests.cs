﻿using Xunit;
using Xunit.Abstractions;

namespace BridgeDesignPattern.NewRequirement
{
    public class BadmintonCourtBookingTests
    {
        private readonly ITestOutputHelper _output;

        public BadmintonCourtBookingTests(ITestOutputHelper output)
        {
            _output = output;
        }

        [Fact]
        public void InitialHalfYearlyBooking()
        {
            var halfyearlyBooking = new BadmintonCourtHalfYearBooking();
            var result = halfyearlyBooking.GetPrice();
            _output.WriteLine(result.ToString());
        }

        [Fact]
        public void InitialYearlyBooking()
        {
            var yearlyBooking = new BadmintonCourtYearlyBooking();
            var result = yearlyBooking.GetPrice();
            _output.WriteLine(result.ToString());
        }  
        
        [Fact]
        public void BadmintonCourtYearlyGirlsBooking()
        {
            var yearlyBooking = new BadmintonCourtYearlyGirlsBooking();
            var result = yearlyBooking.GetPrice();
            _output.WriteLine(result.ToString());
        }
    }
}
