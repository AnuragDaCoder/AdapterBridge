﻿
namespace BridgeDesignPattern.NewRequirement
{
    public interface IBadmintonMembershipBooking
    {
        public decimal GetPrice();
    }
}
