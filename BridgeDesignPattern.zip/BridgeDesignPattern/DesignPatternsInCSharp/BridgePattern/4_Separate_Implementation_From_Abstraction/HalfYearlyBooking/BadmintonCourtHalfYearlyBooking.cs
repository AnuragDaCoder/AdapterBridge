﻿
namespace BridgeDesignPattern4_Separate_Implementation_From_Abstraction
{
    public class BadmintonCourtHalfYearlyBooking : IBadmintonMembershipBooking
    {
        private readonly IDiscount _discount;
        public BadmintonCourtHalfYearlyBooking(IDiscount discount)
        {
            _discount = discount;
        }
        public decimal GetPrice() => 10000 * _discount.GetDiscount();
    }
}
