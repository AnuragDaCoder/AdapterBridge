﻿namespace BridgeDesignPattern4_Separate_Implementation_From_Abstraction
{
    public interface IBadmintonMembershipBooking 
    {
        public decimal GetPrice();
    }
}
