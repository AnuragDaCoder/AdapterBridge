﻿
namespace BridgeDesignPattern4_Separate_Implementation_From_Abstraction
{
    public class GirlsDiscount : IDiscount
    {
        public decimal GetDiscount()
        {
            return (decimal)0.8;
        }
    }
}
