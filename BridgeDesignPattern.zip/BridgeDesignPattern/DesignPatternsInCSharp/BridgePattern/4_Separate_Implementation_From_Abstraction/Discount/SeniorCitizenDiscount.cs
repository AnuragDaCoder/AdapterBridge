﻿
namespace BridgeDesignPattern4_Separate_Implementation_From_Abstraction
{
    public class SeniorCitizenDiscount : IDiscount
    {
        public decimal GetDiscount()
        {
            return (decimal)0.6;
        }
    }
}
