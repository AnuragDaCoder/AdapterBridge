﻿
namespace BridgeDesignPattern4_Separate_Implementation_From_Abstraction
{
    public interface IDiscount
    {
        public decimal GetDiscount();
    }
}
