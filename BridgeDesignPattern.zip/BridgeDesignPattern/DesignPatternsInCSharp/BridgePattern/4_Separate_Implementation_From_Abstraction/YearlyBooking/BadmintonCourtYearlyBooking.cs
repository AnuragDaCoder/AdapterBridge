﻿
namespace BridgeDesignPattern4_Separate_Implementation_From_Abstraction
{
    public class BadmintonCourtYearlyBooking : IBadmintonMembershipBooking
    {
        private readonly IDiscount _discount;
        public BadmintonCourtYearlyBooking(IDiscount discount)
        {
            _discount = discount;
        }
        public decimal GetPrice() => 15000 * _discount.GetDiscount();
    }
}
