﻿
namespace BridgeDesignPattern.IntialStage
{
    public interface IBadmintonMembershipBooking
    {
        public decimal GetPrice();
    }
}
