﻿
namespace BridgeDesignPattern.IntialStage
{
    public class BadmintonCourtYearlyBooking : IBadmintonMembershipBooking
    {
        public decimal GetPrice() => 15000;
       
    }
}
