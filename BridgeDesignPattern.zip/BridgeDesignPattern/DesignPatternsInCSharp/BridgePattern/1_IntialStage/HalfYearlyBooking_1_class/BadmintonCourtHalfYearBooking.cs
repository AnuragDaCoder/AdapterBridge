﻿
namespace BridgeDesignPattern.IntialStage
{
    public class BadmintonCourtHalfYearBooking : IBadmintonMembershipBooking
    {
        public decimal GetPrice() => 10000;
        
    }
}
